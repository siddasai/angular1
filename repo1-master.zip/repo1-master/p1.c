# include <srdio.h>
main()
{
	printf("welcome to githuib");
}
